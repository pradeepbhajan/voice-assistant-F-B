from pydantic import BaseModel
from datetime import datetime

class CommandBase(BaseModel):
    text: str
    language: str
    status: str

class CommandCreate(CommandBase):
    pass

class CommandOut(CommandBase):
    id: int
    timestamp: datetime

    class Config:
        orm_mode = True
