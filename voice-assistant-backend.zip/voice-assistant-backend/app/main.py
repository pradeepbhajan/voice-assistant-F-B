from fastapi import FastAPI
from . import models, database, api

app = FastAPI(title="Voice Assistant Backend")
models.Base.metadata.create_all(bind=database.engine)
app.include_router(api.router)
