from sqlalchemy.orm import Session
from . import models, schemas

def create_command(db: Session, cmd: schemas.CommandCreate):
    db_cmd = models.VoiceCommand(**cmd.dict())
    db.add(db_cmd)
    db.commit()
    db.refresh(db_cmd)
    return db_cmd

def get_all_commands(db: Session):
    return db.query(models.VoiceCommand).order_by(models.VoiceCommand.timestamp.desc()).all()
