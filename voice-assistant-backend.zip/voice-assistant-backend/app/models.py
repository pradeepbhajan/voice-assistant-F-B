from sqlalchemy import Column, Integer, String, DateTime
from datetime import datetime
from .database import Base

class VoiceCommand(Base):
    __tablename__ = "voice_commands"
    id = Column(Integer, primary_key=True, index=True)
    text = Column(String, nullable=False)
    language = Column(String, default="en")
    status = Column(String, default="success")
    timestamp = Column(DateTime, default=datetime.utcnow)
