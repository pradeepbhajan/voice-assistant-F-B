from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from . import crud, schemas, database

router = APIRouter()

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/commands/", response_model=schemas.CommandOut)
def add_command(cmd: schemas.CommandCreate, db: Session = Depends(get_db)):
    return crud.create_command(db, cmd)

@router.get("/commands/", response_model=list[schemas.CommandOut])
def list_commands(db: Session = Depends(get_db)):
    return crud.get_all_commands(db)
