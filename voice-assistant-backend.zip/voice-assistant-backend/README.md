# Voice Assistant Backend

This project provides a FastAPI backend for storing and retrieving voice commands.

## Setup Instructions

1. Create and activate a virtual environment:
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Create PostgreSQL database named `voice_db` and configure your user credentials.

4. Run the server:
   ```
   uvicorn app.main:app --reload
   ```

5. Access API docs at: http://localhost:8000/docs
