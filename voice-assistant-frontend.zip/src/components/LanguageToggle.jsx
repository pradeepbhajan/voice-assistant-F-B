import React from 'react';

function LanguageToggle({ language, setLanguage }) {
  return (
    <div>
      <button onClick={() => setLanguage("en")} disabled={language === "en"}>English</button>
      <button onClick={() => setLanguage("hi")} disabled={language === "hi"}>Hindi</button>
    </div>
  );
}

export default LanguageToggle;
