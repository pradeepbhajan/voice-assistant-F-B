import React, { useState } from 'react';

function MicInput({ onSend }) {
  const [text, setText] = useState("");

  const handleSubmit = () => {
    if (text.trim()) {
      onSend(text);
      setText("");
    }
  };

  return (
    <div>
      <input value={text} onChange={e => setText(e.target.value)} placeholder="Speak or type command..." />
      <button onClick={handleSubmit}>Send</button>
    </div>
  );
}

export default MicInput;
