import React from 'react';

function CommandList({ commands }) {
  return (
    <div>
      <h3>Recent Commands</h3>
      <ul>
        {commands.map((cmd, i) => (
          <li key={i}>{cmd.text} - {cmd.language}</li>
        ))}
      </ul>
    </div>
  );
}

export default CommandList;
