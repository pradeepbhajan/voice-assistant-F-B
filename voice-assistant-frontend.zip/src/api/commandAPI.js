import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:8000' });

export const addCommand = (data) => API.post('/commands/', data);
export const fetchCommands = () => API.get('/commands/');
