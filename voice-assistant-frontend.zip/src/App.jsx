import React, { useState, useEffect } from 'react';
import { addCommand, fetchCommands } from './api/commandAPI';
import CommandList from './components/CommandList';
import MicInput from './components/MicInput';
import LanguageToggle from './components/LanguageToggle';

function App() {
  const [commands, setCommands] = useState([]);
  const [language, setLanguage] = useState("en");

  const loadCommands = async () => {
    const res = await fetchCommands();
    setCommands(res.data);
  };

  const handleCommand = async (text) => {
    await addCommand({ text, language, status: "success" });
    loadCommands();
  };

  useEffect(() => { loadCommands(); }, []);

  return (
    <div>
      <h1>🎙️ Voice Assistant</h1>
      <LanguageToggle setLanguage={setLanguage} language={language} />
      <MicInput onSend={handleCommand} />
      <CommandList commands={commands} />
    </div>
  );
}

export default App;
