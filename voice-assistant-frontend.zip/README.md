# Voice Assistant Frontend

React UI for connecting to backend API.